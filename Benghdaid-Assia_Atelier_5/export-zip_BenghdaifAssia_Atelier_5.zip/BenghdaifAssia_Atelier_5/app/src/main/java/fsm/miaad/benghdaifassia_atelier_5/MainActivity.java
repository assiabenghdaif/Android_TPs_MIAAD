package fsm.miaad.benghdaifassia_atelier_5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.Manifest;

public class MainActivity extends AppCompatActivity {
    Button localisation;
    TextView coor1,coor2,coor3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        localisation=findViewById(R.id.localisation);
        coor1=findViewById(R.id.coor1);
        coor2=findViewById(R.id.coor2);
        coor3=findViewById(R.id.coor3);

        localisation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocalisation(coor1,coor2,coor3);
            }
        });



    }

    private void getLocalisation(TextView coor1,TextView coor2,TextView coor3) {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
            return;
        }

        Location location_GPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        Location location_NETWORK = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        if (location_GPS != null) {
            coor1.setText("Latitude: " + location_GPS.getLatitude() );
            coor2.setText("Longitude: " + location_GPS.getLongitude() );
            coor3.setText("Altitude: " + location_GPS.getAltitude() );
        } else {
            coor1.setText("Latitude: " + location_NETWORK.getLatitude() );
            coor2.setText("Longitude: " + location_NETWORK.getLongitude() );
            coor3.setText("Altitude: " + location_NETWORK.getAltitude() );
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocalisation(coor1,coor2,coor3);
            }
        }
    }
}