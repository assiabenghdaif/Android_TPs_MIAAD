package fsm.miaad.benghdaifassia_atelier_7;

import androidx.appcompat.app.AppCompatActivity;

        import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] linear_acceleration = new float[3];
    private TextView activityStandingConfidenceTextView;
    private TextView activitySittingConfidenceTextView;
    private TextView activityWalkingConfidenceTextView;
    private TextView activityJumpingConfidenceTextView;
    private int[] confidenceValues = new int[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        activityStandingConfidenceTextView = findViewById(R.id.activityStandingConfidenceTextView);
        activitySittingConfidenceTextView = findViewById(R.id.activitySittingConfidenceTextView);
        activityWalkingConfidenceTextView = findViewById(R.id.activityWalkingConfidenceTextView);
        activityJumpingConfidenceTextView = findViewById(R.id.activityJumpingConfidenceTextView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            final float alpha = 0.8f;
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

            linear_acceleration[0] = event.values[0] - gravity[0];
            linear_acceleration[1] = event.values[1] - gravity[1];
            linear_acceleration[2] = event.values[2] - gravity[2];

            // Determine the activity based on the accelerometer data
            int activity = getActivity(linear_acceleration);



            // Update the confidence values in the table
            confidenceValues[activity] += 1;
            int totalConfidence = 0;
            for (int i = 0; i < confidenceValues.length; i++) {
                totalConfidence += confidenceValues[i];
            }

            if (totalConfidence > 0) {
                int standing=(confidenceValues[0] * 100 / totalConfidence);
                int sitting=(confidenceValues[1] * 100 / totalConfidence);
                int walking=(confidenceValues[2] * 100 / totalConfidence);
                int jumping=(confidenceValues[3] * 100 / totalConfidence);
                activityStandingConfidenceTextView.setText(standing + "%");
                activitySittingConfidenceTextView.setText(sitting+ "%");
                activityWalkingConfidenceTextView.setText(walking + "%");
                activityJumpingConfidenceTextView.setText(jumping + "%");

                int max;
                max=Math.max(standing,Math.max(sitting,Math.max(walking,jumping)));
                if(max==standing) {
                    activityStandingConfidenceTextView.setBackgroundColor(Color.BLUE);
                    activitySittingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityWalkingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityJumpingConfidenceTextView.setBackgroundColor(Color.BLACK);

                }
                else if(max==sitting) {
                    activitySittingConfidenceTextView.setBackgroundColor(Color.BLUE);
                    activityWalkingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityJumpingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityStandingConfidenceTextView.setBackgroundColor(Color.BLACK);

                }
                else if(max==walking) {
                    activityWalkingConfidenceTextView.setBackgroundColor(Color.BLUE);
                    activityJumpingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activitySittingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityStandingConfidenceTextView.setBackgroundColor(Color.BLACK);


                }
                else if(max==jumping) {
                    activityJumpingConfidenceTextView.setBackgroundColor(Color.BLUE);
                    activityWalkingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activitySittingConfidenceTextView.setBackgroundColor(Color.BLACK);
                    activityStandingConfidenceTextView.setBackgroundColor(Color.BLACK);


                }
            }


        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    private int getActivity(float[] acceleration) {
        // Determine the activity based on the accelerometer data
        int activity;
        Float x = acceleration[0];
        Float y = acceleration[1];
        Float z = acceleration[2];

        Float magnitude = (float) Math.sqrt(x * x + y * y + z * z);

        if (magnitude < 2.0f) {
            activity = 0; // Standing
        } else if (magnitude < 5.0f) {
            activity = 1; // Sitting
        } else if (magnitude < 8.0f) {
            activity = 2; // Walking
        } else {
            activity = 3; // Jumping
        }
        return activity;
    }
}
