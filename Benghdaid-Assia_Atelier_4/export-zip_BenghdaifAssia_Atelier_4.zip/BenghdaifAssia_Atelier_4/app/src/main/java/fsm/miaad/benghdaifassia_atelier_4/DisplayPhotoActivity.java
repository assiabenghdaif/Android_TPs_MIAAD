package fsm.miaad.benghdaifassia_atelier_4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;;

public class DisplayPhotoActivity extends AppCompatActivity {






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_photo);
        ImageView imageView = (ImageView) findViewById(R.id.imageView1);

        Bitmap imageBitmap = getIntent().getParcelableExtra("imageBitmap");
        imageView.setImageBitmap(imageBitmap);

//        Bitmap imageBitmap = (Bitmap) getIntent().getExtras().get("imageBitmap");
//        imageView.setImageBitmap(imageBitmap);
//        setContentView(imageView);



    }

}

