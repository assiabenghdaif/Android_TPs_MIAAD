package fsm.miaad.benghdaifassia_atelier_4;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;

public class MyCameraActivity extends Activity {
    private static final int CAMERA_REQUEST = 1888;
    private ImageView imageView;
    private Button buttonshow;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
//        this.imageView = (ImageView)this.findViewById(R.id.imageView1);
        Button photoButton = (Button) this.findViewById(R.id.button1);
//        Intent c;
        photoButton.setOnClickListener(new View.OnClickListener() {
            Intent cameraIntent;
            @Override
            public void onClick(View v) {
                launchCamera();

            }
        });


    }

    private void launchCamera() {
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
//
        startActivityForResult(cameraIntent, CAMERA_REQUEST);
    }
    private void displayImage(Bitmap imageBitmap) {

        Intent intent = new Intent(this, DisplayPhotoActivity.class);
        intent.putExtra("imageBitmap", imageBitmap);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
            displayImage(imageBitmap);
        }
    }


}